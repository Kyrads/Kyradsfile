
DrawVertical

---

This module extends and retracts the window from the top/bottom of the screen (rather than from the side, which is how the vanilla window extends/retracts).
