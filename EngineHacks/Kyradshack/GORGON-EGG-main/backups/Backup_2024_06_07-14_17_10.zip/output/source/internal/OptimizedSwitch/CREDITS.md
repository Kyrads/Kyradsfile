
This is based on research done by [Contro](https://github.com/masterofcontroversy/).
