
#include "gbafe.h"

extern const u16 GETilemap_1[];