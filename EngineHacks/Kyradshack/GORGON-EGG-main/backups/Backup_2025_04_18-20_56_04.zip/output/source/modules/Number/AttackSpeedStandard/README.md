
AttackSpeedStandard

---

This module draws a number for the unit's attack speed number.

---

Definitions:

  * `AS_X`: The X position of the rightmost digit, in pixels
  * `AS_Y`: The Y position of the rightmost digit, in pixels
  * `NUMBER_BASE_TILE`: The VRAM tile index of the first number tile
  * `NUMBER_PALETTE`: The PalRAM index of the number palette
