
NameLeftAligned

---

This module draws the selected unit's name, left-aligned in available space.

---

Definitions:

  * `NAME_X`: The X coordinate of the name text in tiles
  * `NAME_Y`: The Y coordinate of the name text in tiles
  * `NAME_WIDTH`: The amount of space allocated for the name in tiles
  * `NAME_COLOR`: The text's color
